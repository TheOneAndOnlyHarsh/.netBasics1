﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basics
{
    internal class Student
    {
        // declaring a static and private variable

        
        private  static string schoolName = "Maharaja Surajmal School";



        // decalaring variables in  a class:
       
        public string studentName{get ; set;}
        public int studentId { get ; set;}
        public string standard { get ; set;}

        List<Marks> marks = new List<Marks>();

       

        // no params constructor:
        public Student() {
        }


        public Student(String schoolName) {

            this.studentName = schoolName;
               
        }
        //all params constructor:
        public Student(string studentName, int studentId, string standard)
        {
            this.studentName = studentName;
            this.studentId = studentId;
            this.standard = standard;
        }




        // creating methods all are public : 

        public void admission(int studentId , string studentName , double marks ) {
        
        }
        public void transfer(int studentId, string studentName, double marks) { 
        
        }
            


    }
}
