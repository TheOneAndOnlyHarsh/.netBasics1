﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();

            student = new Student("Harsh" ,243 ,"Fifth");

            string firstObj = student.ToString();

         //   Console.WriteLine($"id:{student.studentId} name:{student.studentName} class:{student.standard} ");

            // student.schoolname --> wil not work as it is static

           //  Console.WriteLine(Student.schoolName); --> this will work if the key is public 

            Marks marks = new Marks();

          //  Console.WriteLine(marks.method());

            // exception handeling 
            DivNumbers d = new DivNumbers();
            d.division(25, 0);
            Console.ReadKey();
        }
    }
}
