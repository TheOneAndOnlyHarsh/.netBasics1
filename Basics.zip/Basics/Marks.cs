﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basics
{
    internal class Marks
    {
        private int physics { get; set; }

        private int Maths { get; set; }

        private int english { get; set; }

        private int hindi { get; set; }
       
        
        public Marks() { }

        public Marks(int physics, int maths, int english, int hindi)
        {
            this.physics = physics;
            Maths = maths;
            this.english = english;
            this.hindi = hindi;
        }

        public string method() {

            return "method inside Marks ";    
        
         }
    }

}
